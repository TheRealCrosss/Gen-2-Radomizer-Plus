# Gen 2 Randomizer+ — Gold v2.00

A customizable randomizer and rematch overhaul for Pokémon Recomp Gen 2: Gold.

## Features

- Trainer and Gym Leader rematches after defeat
- Optional Progressive Levels up to Level 100
- Random trainer Pokémon
- Random trainer stats and moves
- Random wild Pokémon from all 251 species while preserving area encounter levels
- Random wild stats and moves
- Random Pokémon types
- Type-based expanded TM/HM compatibility for randomized types
- Randomized Elm starters using only base-stage and single-stage Pokémon
- Natural evolutions and level-up moves when move randomization is disabled
- Trade evolutions at Level 45 during progressive rematches
- Customizable rematch XP and money rewards
- Persistent settings and trainer progression

## Randomizer+ Settings

Settings are available directly from the START menu and persist between sessions. Randomizer options are OFF by default unless otherwise noted.

### Trainer Rematches
Talk to a trainer or Gym Leader you have already defeated. Choose YES to battle them again or NO to hear their normal post-battle dialogue.

### Progressive Levels
When enabled, each rematch increases that trainer's Pokémon by one level, up to Level 100. Pokémon evolve and learn their natural moves as they level. Turning Progressive Levels OFF returns trainers to their original teams and levels unless another randomizer option is enabled.

### Random Trainer Pokémon
Randomizes trainer Pokémon during rematches while preserving the appropriate rematch level.

### Random Trainer Stats & Moves
Gives rematch Pokémon randomized legal Gen 2 stats and four random valid Gold moves.

### Random Wild Pokémon
Wild encounters can become any of all 251 Pokémon while retaining the original encounter level selected for that area. Early routes therefore remain low-level even when rare or powerful species appear.

### Wild Random Stats & Moves
Wild Pokémon receive randomized legal Gen 2 stats and four random valid moves.

### Random Types
Randomizes Pokémon types. Battle typing, STAB, weaknesses, resistances, and immunities use the randomized type. TM/HM compatibility is also expanded to include compatible moves matching the Pokémon's randomized type.

### Random Starters
Randomizes Elm's three starter choices. Only base-stage Pokémon and true single-stage Pokémon are eligible; evolved forms such as Hypno, Dragonair, and Dragonite are excluded. The rival's starter stays synchronized with the randomized starter trio.

## Compatibility

- Pokémon Recomp Gen 2: Gold
- Existing Trainer Rematch 2 save data/settings remain compatible because the internal mod ID is intentionally unchanged.


### Random Learnset — v2.0.9 clean rebuild
- Built fresh from the known-good v2.00 release rather than an experimental branch.
- Every owned Pokémon receives a brand-new V9 per-individual level-up schedule.
- The same species can have completely different schedules on different individuals.
- Existing/current moves are rebuilt from that individual schedule on first enrollment so the feature is immediately visible.
- Future vanilla level-up writes are replaced through both `pokemon.move_learned` and a fixed-step reconciliation fallback.
- Old v2.0.1-v2.0.8 experimental save fields are ignored completely.

### Random Starter Moves
- `STARTER MOVES` remains a separate OFF-by-default option.
- If both Random Learnset and Starter Moves are enabled, Starter Moves controls only the starter's initial moves; its future level-up schedule remains individually randomized.


### Random World Items — v2.5.0 Test
**RANDOM WORLD ITEMS** is OFF by default. When enabled, visible Poké Ball pickups and hidden field items are randomized for the playthrough. Key-item pickups stay vanilla and key items are never selected as replacements. Scripted NPC gifts and rewards are not affected.
